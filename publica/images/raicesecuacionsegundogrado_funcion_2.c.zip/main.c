/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>
#include <stdbool.h>
void ecuacion_2grado(float a, float b, float c, float *ptr_r1, float *ptr_r2, bool *ptr_raices_imaginarias);

int main()
{
    float a, b, c, r1, r2;
    bool raices_imaginarias;
    raices_imaginarias = false;
    
    a = 0; // asigno valor a la variable a para controlarlo

    // Compruebo que tengo un valor de a mayor que 0 (no seria una ecuacion de segundo grado)
    while(a==0)
    {
        printf("\nEl valor de a no puede ser 0. Introduce el valor de a: ");
        scanf("%f", &a);
    }
    
    // Pido el valor de b
    printf("\nIntroduce el valor de b: ");
    scanf("%f", &b);
    
    // Pido el valor de c    
    printf("\nIntroduce el valor de c: ");
    scanf("%f", &c);
    
    // Llamo a la funcion
    ecuacion_2grado(a, b, c, &r1, &r2, &raices_imaginarias);
    
    // Imprimo los valores
    if (raices_imaginarias)
    {
        // Hay raices imaginarias
        printf("\nLa parte real es %.2f y la imaginaria es %.2fi", r1, r2);
        printf("\nLas raices imaginarias serian: %.2f+%.2fi y %.2f-%.2fi", r1, r2, r1, r2);
    }
    else
    {
        // No hay raices imaginarias
        printf("\nLas dos raices son reales");
        printf("\nraiz1=%.2f \nraiz2=%.2f", r1, r2);
    }
    
    return 0;
    
}
    
void ecuacion_2grado(float a, float b, float c, float *ptr_r1, float *ptr_r2, bool *ptr_raices_imaginarias)
{
    float discriminante;
    // Calculo el valor del discriminante
    discriminante = pow(b, 2.0)-4*a*c;
    
    // Compruebo si las raices son reales o imaginarias
    if(discriminante > 0.0)
    {
        // Las raices son reales porque el discriminante es mayor que 0
        *ptr_r1 = ((-b + sqrt(discriminante)) / (2.0 * a));
        *ptr_r2 = ((-b - sqrt(discriminante)) / (2.0 * a));
        *ptr_raices_imaginarias = false;  
    } 
    else if(discriminante == 0.0) // Tengo que comprobar dos posibles casos: que el discriminante sea 0 o que sea menor que 0
    {
        *ptr_r1 = (-b)/(2.0*a);
        *ptr_r2 = *ptr_r1; // solo hay una raiz y la pongo igual en los dos sitios
        *ptr_raices_imaginarias = false;        
    }
    else
    {
        // El discriminante es menor que 0. Tengo raices imaginarias
        // Cuidado: he hecho una guarreria. He utilizado las mismas variables y punteros de las raices reales
        // para las raices imaginarias con la parte real en r1 y la parte imaginaria en r2
        *ptr_r1 = (-b / (2.0 * a));
        *ptr_r2 = (sqrt(-discriminante) / (2.0 * a));
        *ptr_raices_imaginarias = true;
    }
    return;
} 







